-- Setup steps (run once outside the pipeline, e.g. in the SQL editor):
-- CREATE CATALOG IF NOT EXISTS edtech_catalog; -- or use a catalog you already have
-- CREATE SCHEMA IF NOT EXISTS edtech_catalog.learning;
-- CREATE VOLUME IF NOT EXISTS edtech_catalog.learning.raw_files;
-- Upload course_enrollments_raw.csv into the volume (Catalog Explorer → raw_files → Upload)
-- Preview it with:
-- SELECT * FROM read_files('/Volumes/course_enrollment/default/course_volume/course_enrollments_raw.csv',
-- format => 'csv', header => true) LIMIT 10;
-- Pipelines only accept dataset definitions (CREATE STREAMING TABLE / MATERIALIZED VIEW) and SET.

CREATE OR REFRESH STREAMING TABLE bronze_course_enrollments AS
SELECT *,
_metadata.file_name AS source_file,
current_timestamp() AS loaded_at
FROM STREAM read_files('/Volumes/course_enrollment/default/course_volume/',
format => 'csv', header => true);