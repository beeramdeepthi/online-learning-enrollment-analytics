-- Silver: four cleaning steps per the project spec.
-- 1. Remove duplicates (SELECT DISTINCT on the cleaned values)
-- 2. Fix text (INITCAP for names/categories, LOWER for emails)
-- 3. Fill blanks (COALESCE) and add learner_status
-- 4. Check rules (EXPECT ... ON VIOLATION DROP ROW); failing rows go to
--    silver_enrollments_rejected instead.

CREATE OR REFRESH MATERIALIZED VIEW silver_enrollments_clean (
  CONSTRAINT valid_progress EXPECT (progress_pct BETWEEN 0 AND 100) ON VIOLATION DROP ROW,
  CONSTRAINT valid_price EXPECT (price_paid >= 0) ON VIOLATION DROP ROW
)
AS
WITH cleaned AS (
  SELECT DISTINCT
    TRIM(enrollment_id)                                     AS enrollment_id,
    TRIM(learner_id)                                        AS learner_id,
    LOWER(TRIM(learner_email))                               AS learner_email,
    COALESCE(INITCAP(TRIM(learner_city)), 'Unknown')          AS learner_city,
    TRIM(age_group)                                          AS age_group,
    TRIM(course_id)                                         AS course_id,
    TRIM(course_name)                                       AS course_name,
    COALESCE(INITCAP(TRIM(category)), 'Unknown')              AS category,
    INITCAP(TRIM(course_level))                              AS course_level,
    TRIM(instructor_name)                                   AS instructor_name,
    enrollment_date,
    INITCAP(TRIM(enrollment_channel))                        AS enrollment_channel,
    CAST(list_price AS DECIMAL(10,2))                        AS list_price,
    CAST(discount_amount AS DECIMAL(10,2))                   AS discount_amount,
    COALESCE(CAST(price_paid AS DECIMAL(10,2)),
             CAST(list_price AS DECIMAL(10,2))
             - CAST(discount_amount AS DECIMAL(10,2)))         AS price_paid,
    TRIM(payment_method)                                     AS payment_method,
    progress_pct,
    CAST(hours_watched AS DECIMAL(10,2))                     AS hours_watched,
    course_rating,
    TRIM(certificate_issued)                                 AS certificate_issued
  FROM bronze_course_enrollments
)
SELECT *,
  CASE WHEN progress_pct = 100 THEN 'Completed'
       WHEN progress_pct > 0 THEN 'In Progress'
       ELSE 'Not Started' END AS learner_status
FROM cleaned;

CREATE OR REFRESH MATERIALIZED VIEW silver_enrollments_rejected
COMMENT 'Bronze enrollments that fail the progress or price rules, with the reason'
AS
SELECT *,
  CASE WHEN progress_pct < 0 OR progress_pct > 100 THEN 'Progress is outside 0 to 100'
       ELSE 'Price paid is negative' END AS reject_reason
FROM bronze_course_enrollments
WHERE progress_pct < 0 OR progress_pct > 100 OR price_paid < 0;