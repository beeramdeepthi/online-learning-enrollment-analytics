-- Gold: business-ready summary views per the project spec (BR-01 to BR-06),
-- built from silver_enrollments_clean / silver_enrollments_rejected / bronze.

-- BR-01: Monthly trends.
CREATE OR REFRESH MATERIALIZED VIEW gold_monthly_enrollments
COMMENT 'Monthly enrollments, unique learners, revenue, discount, completions and hours watched'
CLUSTER BY (enrollment_month)
AS
SELECT DATE_TRUNC('MONTH', enrollment_date) AS enrollment_month,
COUNT(*) AS enrollments,
COUNT(DISTINCT learner_email) AS unique_learners,
SUM(price_paid) AS revenue,
SUM(discount_amount) AS discount_amount,
SUM(CASE WHEN learner_status = 'Completed' THEN 1 ELSE 0 END) AS completions,
SUM(hours_watched) AS hours_watched
FROM silver_enrollments_clean
GROUP BY DATE_TRUNC('MONTH', enrollment_date);

-- BR-02: Category performance.
CREATE OR REFRESH MATERIALIZED VIEW gold_category_summary
COMMENT 'Enrollments, revenue, status counts, completion rate and average progress by category'
CLUSTER BY (category)
AS
SELECT category,
COUNT(*) AS enrollments,
SUM(price_paid) AS revenue,
SUM(CASE WHEN learner_status = 'Completed' THEN 1 ELSE 0 END) AS completed,
SUM(CASE WHEN learner_status = 'In Progress' THEN 1 ELSE 0 END) AS in_progress,
SUM(CASE WHEN learner_status = 'Not Started' THEN 1 ELSE 0 END) AS not_started,
ROUND(100.0 * SUM(CASE WHEN learner_status = 'Completed' THEN 1 ELSE 0 END) / COUNT(*), 1) AS completion_rate_pct,
ROUND(AVG(progress_pct), 1) AS avg_progress_pct
FROM silver_enrollments_clean
GROUP BY category;

-- BR-03: Course performance.
CREATE OR REFRESH MATERIALIZED VIEW gold_course_summary
COMMENT 'Enrollments, revenue, completion rate, average rating and hours watched by course'
CLUSTER BY (category, course_name)
AS
SELECT category, course_name, course_level, instructor_name,
COUNT(*) AS enrollments,
SUM(price_paid) AS revenue,
ROUND(100.0 * SUM(CASE WHEN learner_status = 'Completed' THEN 1 ELSE 0 END) / COUNT(*), 1) AS completion_rate_pct,
ROUND(AVG(course_rating), 2) AS avg_rating,
SUM(hours_watched) AS hours_watched
FROM silver_enrollments_clean
GROUP BY category, course_name, course_level, instructor_name;

-- BR-04: Channel analysis.
CREATE OR REFRESH MATERIALIZED VIEW gold_channel_summary
COMMENT 'Enrollments, revenue and completion rate by enrollment channel'
CLUSTER BY (enrollment_channel)
AS
SELECT enrollment_channel,
COUNT(*) AS enrollments,
SUM(price_paid) AS revenue,
ROUND(100.0 * SUM(CASE WHEN learner_status = 'Completed' THEN 1 ELSE 0 END) / COUNT(*), 1) AS completion_rate_pct
FROM silver_enrollments_clean
GROUP BY enrollment_channel;

-- BR-05 / BR-06: Data quality and reconciliation.
-- Proves bronze rows = clean rows + rejected rows + duplicate rows removed.
CREATE OR REFRESH MATERIALIZED VIEW gold_data_quality
COMMENT 'Problem counts in bronze, learner counts before/after the email fix, and the reconciliation check'
AS
WITH bronze_stats AS (
  SELECT
    COUNT(*) AS bronze_rows,
    COUNT(*) - COUNT(DISTINCT enrollment_id) AS duplicate_rows,
    SUM(CASE WHEN progress_pct < 0 OR progress_pct > 100 THEN 1 ELSE 0 END) AS invalid_progress_rows,
    SUM(CASE WHEN price_paid < 0 THEN 1 ELSE 0 END) AS negative_price_rows,
    SUM(CASE WHEN category IS NULL OR TRIM(category) = '' THEN 1 ELSE 0 END) AS missing_category_rows,
    SUM(CASE WHEN learner_city IS NULL OR TRIM(learner_city) = '' THEN 1 ELSE 0 END) AS missing_city_rows,
    SUM(CASE WHEN price_paid IS NULL THEN 1 ELSE 0 END) AS missing_price_rows,
    SUM(CASE WHEN learner_email <> LOWER(TRIM(learner_email)) THEN 1 ELSE 0 END) AS messy_email_rows,
    COUNT(DISTINCT learner_email) AS learners_before_email_fix,
    COUNT(DISTINCT LOWER(TRIM(learner_email))) AS learners_after_email_fix
  FROM bronze_course_enrollments
)
SELECT
  bs.*,
  (SELECT COUNT(*) FROM silver_enrollments_clean) AS clean_rows,
  (SELECT COUNT(*) FROM silver_enrollments_rejected) AS rejected_rows,
  bs.learners_before_email_fix - bs.learners_after_email_fix AS double_counted_learners,
  CASE WHEN bs.bronze_rows = (SELECT COUNT(*) FROM silver_enrollments_clean)
                        + (SELECT COUNT(*) FROM silver_enrollments_rejected)
                        + bs.duplicate_rows
       THEN TRUE ELSE FALSE END AS reconciliation_passed
FROM bronze_stats bs;